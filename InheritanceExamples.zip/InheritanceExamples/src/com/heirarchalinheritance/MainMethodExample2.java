package com.heirarchalinheritance;

public class MainMethodExample2 {

	public static void main(String[] args) {

		Multiplication multiplication = new Multiplication();
		multiplication.add();
		multiplication.multiply();
		multiplication.sum();
		
		Subtraction subtraction = new Subtraction();
		subtraction.sub();
		subtraction.add();
		subtraction.sum();
	}
}
