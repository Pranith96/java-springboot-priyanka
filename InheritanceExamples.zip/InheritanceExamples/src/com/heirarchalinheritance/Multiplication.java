package com.heirarchalinheritance;

public class Multiplication extends Addition{

	public void multiply() {
		System.out.println("Multiply");
	}
}
