package com.heirarchalinheritance;

public class Subtraction extends Addition{

	public void sub() {
		System.out.println("Subtraction");
	}
}
