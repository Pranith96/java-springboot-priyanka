/*
 * package com.multipleinheritance;
 * 
 * public class Subtraction extends Addition, Multiplication{
 * 
 * public void sub() { System.out.println("Subtraction"); } }
 */