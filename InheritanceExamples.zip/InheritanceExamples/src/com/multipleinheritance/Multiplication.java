package com.multipleinheritance;

public class Multiplication {

	public void multiply() {
		System.out.println("Multiply");
	}
}
