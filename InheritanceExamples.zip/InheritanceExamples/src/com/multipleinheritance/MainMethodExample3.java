package com.multipleinheritance;

public class MainMethodExample3 {

	public static void main(String[] args) {

			}
	

}
