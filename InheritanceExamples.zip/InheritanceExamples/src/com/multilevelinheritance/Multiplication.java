package com.multilevelinheritance;

public class Multiplication extends Summation{

	public void multiply() {
		System.out.println("Multiply");
	}
}
