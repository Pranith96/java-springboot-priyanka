package com.multilevelinheritance;

public class MainMethodExample1 {

	public static void main(String[] args) {

		Subtraction subtraction = new Subtraction();
		subtraction.add();
		subtraction.multiply();
		subtraction.sub();
		subtraction.sum();
		subtraction.print();

	}

}
