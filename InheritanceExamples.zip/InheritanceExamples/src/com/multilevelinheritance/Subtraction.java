package com.multilevelinheritance;

public class Subtraction  extends Multiplication{

	public void sub() {
		System.out.println("Subtraction");
	}
}
