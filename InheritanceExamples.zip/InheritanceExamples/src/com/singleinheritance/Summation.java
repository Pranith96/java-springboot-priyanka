package com.singleinheritance;

public class Summation extends Addition {

	public void print() {
		System.out.println("print");
	}
}
