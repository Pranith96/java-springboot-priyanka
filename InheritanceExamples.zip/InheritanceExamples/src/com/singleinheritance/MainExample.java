package com.singleinheritance;

public class MainExample {

	public static void main(String[] args) {

		Summation summation = new Summation();
		summation.add();
		summation.print();
		summation.sum();
	}

}
